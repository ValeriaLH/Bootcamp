class Cuenta_Bancaria:

    toda_info = []
    def __init__(self, tasa_interés, balance):
        self.tasa_interés = tasa_interés
        self.balance = balance

    def deposito(self, monto):
        self.balance += monto
        return self

    def retiro(self, monto):
        self.balance -= monto
        if self.balance < 0:
            print("Fondos insuficientes: cobrando una tarifa de $5")
            self.balance = self.balance - 5
        return self

    def mostrar_info_cuenta(self):
        print("Balance: $",self.balance)

    def generar_interés(self):
        if self.balance > 0:
            self.balance += self.balance * self.tasa_interés
        return self


