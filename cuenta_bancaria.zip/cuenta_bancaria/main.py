from Cuenta_bancaria import Cuenta_Bancaria

Cuenta_1 = Cuenta_Bancaria(2.5, 3000)
Cuenta_2 = Cuenta_Bancaria(2.0, 3500)


Cuenta_1.deposito(1500).deposito(2500).deposito(3000).retiro(3500).generar_interés().mostrar_info_cuenta()
print(Cuenta_1.balance)

Cuenta_2.deposito(15000).deposito(2500).retiro(500).retiro(1500).retiro(200).retiro(3000).generar_interés().mostrar_info_cuenta()
print(Cuenta_2.balance)

classmethod()