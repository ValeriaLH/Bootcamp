class Usuario:
    # 1 se crea una función para inicializar a la persona
    def __init__(self, nombre, apellido, monto): 
        self.nombre = nombre
        self.apellido = apellido
        self.monto = monto
    
    # 2 método que reduce el balance del usuario en la cantidad especificada 
    def hacer_retiro(self, retiro):
        self.monto -= retiro

    # 3 método que aumenta el balance del usuario en la cantidad especificada 
    def hacer_deposito(self, deposito):
        self.monto += deposito

    # 4 método que hace que el primer usuario transfiera dinero al terecer usuario
    def hacer_transferencia(self, persona2, transferencia):
        if self.monto >= transferencia:
            self.monto -= transferencia
            persona2.monto += transferencia
        else:
            print("No es posible realizar la transacción")
