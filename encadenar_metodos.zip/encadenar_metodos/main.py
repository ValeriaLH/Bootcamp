from Usuario import Usuario

## USUARIOS
Harry = Usuario("Harry", "Potter", 200000)
Hermione = Usuario("Hermione", "Granger", 250000)
Ron = Usuario("Ron", "Weasley", 175000)

## El primer usuario hace tres depositos y un giro.
Harry.hacer_deposito(5000).hacer_deposito(15000).hacer_deposito(750).hacer_retiro(50000)
print("USUARIO:", Harry.nombre, Harry.apellido, "BALANCE:", Harry.monto)

## El segundo usuario hace dos depositos y dos giros.
Hermione.hacer_deposito(75000).hacer_deposito(15000).hacer_retiro(5000).hacer_retiro(8000)
print("USUARIO:", Hermione.nombre, Hermione.apellido, "BALANCE:", Hermione.monto)

## El primer usuario hace un deposito y tres giros
Ron.hacer_deposito(7000).hacer_retiro(50000).hacer_retiro(15000).hacer_retiro(260000)
print("USUARIO:", Ron.nombre, Ron.apellido, "BALANCE:", Ron.monto)

## El primer usuario hace transferencia al tercer ususario
Harry.hacer_transferencia(Ron, 70000)
print("USUARIO:", Harry.nombre, Harry.apellido, "BALANCE:", Harry.monto)
print("USUARIO:", Ron.nombre, Ron.apellido, "BALANCE:", Ron.monto)