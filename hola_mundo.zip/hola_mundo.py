# 1. TAREA: imprime "Hola, mundo"
print("Hola, mundo")

# 2. imprime "Hola, Noelle" con el nombre en una variable
name = "Valeria"
print( "Hola,",name)	# con una coma
print( "Hola, "+name  )	# con un +

# 3. imprimir "Hola 42!" con el número en una variable
name = 4
print( "Hola",name,"!" )	# con una coma
print( "Hola "+str(name)+"!" )	# con una +	-- este debería arrojar un error!

# 4. imprimir "Amo comer sushi y pizza" con las comidas en variables
fave_food1 = "papas fritas"
fave_food2 = "pizza"
print("Amo comer {} y {} ".format(fave_food1, fave_food2)) # con .format()
print(f"Amo comer {fave_food1} y {fave_food2}" ) # con una cadena f


# BONUS

hw = "Hola %s" % "mundo" 	# con valores literales
py = "Me encanta Harry Potter %d" % 5 
print(hw, py)

name = "Valeria"
age = 23
print("Mi nombre es %s y tengo %d" % (name, age))

x = "harry potter"
print(x.title()) #salida: Harry Potter
print(x.upper()) #salida: HARRY POTTER
print(x.split()) #salida: ['harry', 'potter']



