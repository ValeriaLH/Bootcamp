## 1 declaración de variable num1, número
num1 = 42 

## 2 declaración de variable num2, número (flotante)
num2 = 2.3 

## 3 declaración de variable boolean, boolean
boolean = True 

## 4 declaración de variable string, string
string = 'Hello World'

## 5 declaración de variable pizza_toppings, lista
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 'Cheese', 'Olives'] 

## 7 declaración de variable person, diccionario
person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False}

## 8 declaración de variable fruit, tupla
fruit = ('blueberry', 'strawberry', 'banana')

## 9 devuelve qué tipo de clase es la variable creada fruta.
print(type(fruit))

## 10 devuelve el el dato que se encuentra en la posición 1 de la lista pizza_toppings.
print(pizza_toppings[1])

## 11 agrega al final de la lista pizza_toppings, el elemento 'Mushrooms'
pizza_toppings.append('Mushrooms')

## 12 devuelve el dato que acompaña a la variable 'name' dentro del diccionario.
print(person['name'])

## 13 cambia el dato que acompaña a 'nombre' por el de 'George'.
person['name'] = 'George'

## 14 agrega al diccionario la variable 'eye_color'.
person['eye_color'] = 'blue'

## 15 devuelve el dato que se encuetra en la posisicion 2 dentro de la tupla fruits.
print(fruit[2])

""" 
16. condicional if; si num1 (42) es mayor a 45, entonces que
    devuelva la frase "It's greater", si no, que devuelva la
    frase "It's lower".
"""
if num1 > 45:
    print("It's greater")
else:
    print("It's lower")

""" 
17. condicional else if; si el largo de la variable 'string' es
    menor a 5, entonces que devuelva la frase "It's a short word!",
    si es mayor a 15, entonces que devuelva la frase "It's a long word!".
    Si no cumple ninguna de las condiciones anteriores, entonce que
    devuelva la frase "Just right!".
"""
if len(string) < 5:
    print("It's a short word!")
elif len(string) > 15:
    print("It's a long word!")
else:
    print("Just right!")

"""
18. for loop que devuelve los primeros cinco números enteros 
    a partir del cero y se detiene en 5.
"""
for x in range(5):
    print(x)

"""
19. for loop que devuelve todos los numeros enteros positivos
    iniciando en 2 y deteniendose en 5.
"""   
for x in range(2,5):
    print(x)

"""
20. for loop que devuelve todos los numeros enteros positivos
    iniciando en 2 y deteniendose en 10, aumentando estos en
    3 unidades.
"""  
for x in range(2,10,3):
    print(x)

"""
21. Se crea la variable x igual a 0. While loop en el cual se
    indica que devuelva todos los numeros menores a 5, aumentando
    estos en una unidad.
"""  

x = 0
while(x < 5):
    print(x)
    x += 1

## 22. Se elimina el ultimo dato de la lista pizza_toppings.
pizza_toppings.pop()

## 22. Se elimina el dato que ocupa el lugar 1 de la lista pizza_toppings.
pizza_toppings.pop(1)

## 23. Devuelve los datos contenidos en el diccioanrio person.
print(person)

## 24. Se elimina la variable 'eye_color' del diccionario person.
person.pop('eye_color')

## 25. Devuelve los datos contenidos en el diccionario person sin la variable 'eye-color'.
print(person)

"""
26. for loop para el elemento topping para la lista toppings, que devuelva
    la frase 'After 1st if statement' si topping es igual a 'Pepperoni' y al resto, si
    es igual a 'Olives', entonces que se detenga.
"""  
print(pizza_toppings)
for topping in pizza_toppings:
    if topping == 'Pepperoni':
        continue
    print('After 1st if statement')
    if topping == 'Olives':
        break

"""
27. se crea, o bien, se define una función. Para cada numero
    del 0 al 9, que devuelva la palabra 'Hello'(10 veces).
"""

def print_hello_ten_times():
    for num in range(10):
        print('Hello')

## 28. Se llama a la funcion 'print_hello_ten_times()'
print_hello_ten_times()

"""
29. se crea, o bien, se define una función. Para cada numero
    de un x rango, que devuelva la palabra 'Hello'(x veces).
"""

def print_hello_x_times(x):
    for num in range(x):
        print('Hello')

"""
30. se le entrega un parametro a la funcion 'print_hello_x_times'
    devolviendo cuatro veces la palabra 'Hello'.
"""

print_hello_x_times(4)

"""
31. se le entrega un parametro a la funcion 'print_hello_x_or_ten_times'
    devolviendo diez veces la palabra 'Hello'.
"""

def print_hello_x_or_ten_times(x = 10):
    for num in range(x):
        print('Hello')

## 32. devuelve 10 veces la palabra 'Hello'.
print_hello_x_or_ten_times()

"""
33. se le entrega un nuevo parametro a la funcion 'print_hello_x_or_ten_times'
    devolviendo cuatro veces la palabra 'Hello'.
"""

print_hello_x_or_ten_times(4)


"""
Bonus section
"""

# 1. NameError: name <variable name> is not defined ya que la variable se crea antes, no despues
# print(num3)
# num3 = 72

# 2. TypeError: 'tuple' object does not support item assignment
# fruit[0] = 'cranberry'

# 3. KeyError: 'favorite_team'
# print(person['favorite_team'])

# 4. IndexError: list index out of range
# print(pizza_toppings[7])

# 5. True
# print(boolean)

# 6. AttributeError: 'tuple' object has no attribute 'append'
# fruit.append('raspberry')

# 7. AttributeError: 'tuple' object has no attribute 'pop'
# fruit.pop(1)