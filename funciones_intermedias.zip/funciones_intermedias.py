######################## ACTUALIZAR VALORES EN DICCIONARIOS Y LISTAS ##############################
###################################################################################################

## 1 Cambia el valor 10 en x a 15. Una vez que hayas terminado, x ahora debería ser [ [5,2,3], [15,8,9] ].
x = [ [5,2,3], [10,8,9] ] 

def cambio_valor(x):
    x[1][0] = 15
    return x   

cambio = cambio_valor(x)
print(cambio)


## 2 Cambia el "apellido” del primer alumno de 'Jordan' a 'Bryant'.
estudiantes = [
    {'first_name':  'Michael', 'last_name' : 'Jordan'},
    {'first_name' : 'John', 'last_name' : 'Rosales'}
]

def cambio_apellido(estudiantes):
    estudiantes[0]['last_name'] = 'Bryant'
    return estudiantes

new_estudiantes = cambio_apellido(estudiantes)
print(new_estudiantes)


## 3 En el directorio_deportes, cambia "Messi" por "Andrés".
directorio_deportes = {
    'basketball' : ['Kobe', 'Jordan', 'James', 'Curry'],
    'fútbol' : ['Messi', 'Ronaldo', 'Rooney']
}

def cambio_deportes(directorio_deportes):
    directorio_deportes['fútbol'][0] = 'Andrés'
    return directorio_deportes

new_directorio = cambio_deportes(directorio_deportes)
print(new_directorio)


## 4 Cambia el valor 20 en z a 30.
z = [ {'x': 10, 'y': 20} ]

def cambio_z(z):
    z[0]['y'] = 30
    return z

new_cambio = cambio_z(z)
print(new_cambio)


######################## ITERAR A TRAVÉS DE UNA LISTA DE DICCIONARIOS #############################
###################################################################################################

## 1 Crea una función iterateDictionary(some_list)para que, dada una lista de diccionarios, la función recorra 
## cada diccionarios de la lista e imprima cada llave y el valor asociado. Por ejemplo, dada la siguiente lista:

lista = [
    {'first_name':  'Michael', 'last_name' : 'Jordan'},
    {'first_name' : 'John', 'last_name' : 'Rosales'},
    {'first_name' : 'Mark', 'last_name' : 'Guillen'},
    {'first_name' : 'KB', 'last_name' : 'Tonel'}
    ]

def iterateDictionary(lista):
    for i in lista:
        print('first name -',i['first_name'],',',' last name -',i['last_name'])

print(iterateDictionary(lista))


######################## OBTENER VALORES DE UNA LISTA EN DICCIONARIOS #############################
###################################################################################################

## 3. Crea una función iterateDictionary2(key_name, some_list)que, dada una lista de diccionarios y
## un nombre de clave, la función imprima el valor almacenado en esa clave para cada diccionario. 
lista = [
    {'first_name':  'Michael', 'last_name' : 'Jordan'},
    {'first_name' : 'John', 'last_name' : 'Rosales'},
    {'first_name' : 'Mark', 'last_name' : 'Guillen'},
    {'first_name' : 'KB', 'last_name' : 'Tonel'}
    ]

def iterateDictionary2(key_name, some_list):
    for i in lista:
        print(i[key_name])

print(iterateDictionary2('first_name', lista))
## print(iterateDictionary2('last_name', lista))


################### ITERAR A TRAVÉS DE UN DICCIONARIO CON VALORES DE LISTA ########################
###################################################################################################

## 4. Crea una función printInfo(some_dict)que, dado un diccionario cuyos valores son todos listas, 
## imprima el nombre de cada clave junto con el tamaño de su lista, y luego imprima los valores asociados
## dentro de la lista de cada clave.

dojo = {
    'ubicaciones': ['San Jose', 'Seattle', 'Dallas', 'Chicago', 'Tulsa', 'DC', 'Burbank'],
    'instructores': ['Michael', 'Amy', 'Eduardo', 'Josh', 'Graham', 'Patrick', 'Minh', 'Devon']
}

def printInfo(dojo):
    print(len(dojo['ubicaciones']), "UBICACIONES")
    for i in dojo['ubicaciones']:
        print(i)
    
    print("============")

    print(len(dojo['instructores']), "INSTRUCTORES")
    for j in dojo['instructores']:
        print(j)

printInfo(dojo)




