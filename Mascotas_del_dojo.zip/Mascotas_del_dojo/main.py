from Ninja import Ninja
from Mascota import Mascota

##BONUS NINJA: Usa módulos para separar las clases en diferentes archivos.

ninja_1 = Ninja("Juana","De Arco", "Gato","1er Lugar", ["galletas", "pescado"])

mascota_1 = Mascota("Nesta", "Angora", ["Galletas", "Pescado"], "Miau")

print(ninja_1.Mascota.nombre)

##SENSEI BONUS: Use Inheritance to create sub classes of pets.

gato_1 = Gato("Cassian", "siamés", "Pescado", "miau")
gato_1.sonido()

perro_1 = Perro("Azriel", "boxer", "Carne", "guau")
perro_1.name()

