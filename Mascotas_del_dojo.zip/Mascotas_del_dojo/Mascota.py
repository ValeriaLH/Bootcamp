class Mascota:

    def __init__(self, name, tipo, golosinas, sonido):
        self.name = name
        self.tipo = tipo
        self.golosinas = golosinas
        self.sonido = sonido
        self.salud = 200
        self.energía = 150

    # dormir() - incrementa la energía de la mascota en 25
    def dormir(self):
        self.energía += 25
        return self

    # comer() - incrementa la energía de la mascota en 5 y la salud en 10
    def comer(self):
        self.energía += 5
        self.salud += 10
        return self

    # jugar() - incrementa la salud de la mascota en 5
    def jugar(self):
        self.salud += 5
        return self

    # ruido() - imprime el sonido que produce la mascota
    def ruido(self):
        print(self.sonido)
        return self

    ##BONUS SENSEI: Usa la herencia para crear subclases de mascotas.
    
    class Gato(Mascota):
    def __init__(self, name, tipo, golosinas, sonido):
        super().__init__(name, tipo, golosinas, sonido)

    class Perro(Mascota):
    def __init__(self, name, tipo, golosinas, sonido):
        super().__init__(name, tipo, golosinas, sonido)

